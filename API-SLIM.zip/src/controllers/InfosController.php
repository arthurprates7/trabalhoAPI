<?php

    namespace src\controllers;

    use Psr\Http\Message\ServerRequestInterface as Request;
    use Psr\Http\Message\ResponseInterface as Response;

    use src\models\Infos as InfosModel;


    class InfosController{

        private $content = array();
        private $httpStatusCode = 406;

        public function store(Request $request, Response $response, array $args){

            try{

                $infos = new InfosModel();

                $infos->setDestiny($request->getParsedBody()['destiny']);
                $infos->setMessage($request->getParsedBody()['message']);
                $infos->setOrigin($request->getParsedBody()['origin']);

                    $infos->store();

                $this->httpStatusCode = 200;

            }catch(\Exception $e){

                $this->content['message'] = $e->getMessage();

            }

            return $response->withJSON(['message'=>'Mensagem inserida com sucesso']);
        }

    }