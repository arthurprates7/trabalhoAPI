<?php


    require_once "../vendor/autoload.php";

    
    $app = new Slim\App(

        [

            'settings' =>[

                'displayErrorDetails' => true,

            ],

        ]


    );
    
    require_once "./routes/infos.php";

    $app->run();

    
?>