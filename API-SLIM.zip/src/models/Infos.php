<?php


    namespace src\models;
    use src\config\Connection;
    use src\controllers\InfosController;

    class Infos extends Connection{

        private $origin;
        private $destiny;
        private $message;

        public function __construct(){

            parent::__construct();

        }

        public function setMessage($message){

            $this->message = $message;
            return $this;

        }

        public function setOrigin($origin){

            $this->origin = $origin;
            return $this;
        }

        public function setDestiny($destiny){

            $this->destiny = $destiny;
            return $this;
        }

        public function getDestiny(){

            return $this->destiny;

        }

        public function getMessage(){

            return $this->message;

        }

        public function getOrigin(){

            return $this->origin;

        }


        public function store(){

            $sql = $this->pdo->prepare(

                "INSERT INTO infos (origin, destiny ,message) VALUES (:origin, :destiny ,:message)"

            );

            $sql->bindParam(":origin", $this->origin);
            $sql->bindParam(":destiny", $this->destiny);
            $sql->bindParam(":message", $this->message);
            $sql->execute();

            if($sql->rowCount() !== 1)
                throw new \Exception("Falha ao inserir Mensagem");

        }


    }