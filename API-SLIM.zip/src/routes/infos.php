<?php

    use src\controllers\InfosController;


    $app->group("/store", function() use ($app){

        $app->post("", InfosController::class . ':store');
    });
